/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.File;


/**
 *
 * @author vincent
 */
public class User {
    

private String firstName;
private String lastName;
private String gender;
private int age;
private String phone;
private String email;
private String continent;
private String hobbies;
private File Photo;



    public User(String firstName, String lastName, String gender, int age, String phone, String email, String continent, String hobbies, File Photo) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.age = age;
        this.phone = phone;
        this.email = email;
        this.continent = continent;
        this.hobbies = hobbies;
        this.Photo = Photo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public File getPhoto() {
        return Photo;
    }

    public void setPhoto(File Photo) {
        this.Photo = Photo;
    }







@Override
public String toString(){
    return """
           User Profile
           ------------------------------
                      Name:%s %s
                      Gender:%s
                      Age:%d
                      Phone:%s
                      Email:%s
                      Continents:%s
                      Hobbies:%s
           """.formatted(firstName, lastName, gender, age, phone, email, continent, hobbies);
           
           
}}





